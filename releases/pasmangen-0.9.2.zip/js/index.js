const popover = initializePopover();
document.body.appendChild(popover);